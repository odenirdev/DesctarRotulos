<?php
# includes the autoloader for libraries installed with composer
require __DIR__ . '/../vendor/autoload.php';

# imports the Google Cloud client library
use Google\Cloud\Vision\V1\ImageAnnotatorClient;

putenv('GOOGLE_APPLICATION_CREDENTIALS='.__DIR__.'\My_First_Project_Google_Cloud.json');

# instantiates a client
$imageAnnotator = new ImageAnnotatorClient();

# the name of the image file to annotate
$fileName = 'C:\Users\user\Documents\foto-de-perfil.jpg';

# prepare the image to be annotated
$image = file_get_contents($fileName);

# performs label detection on the image file
$response = $imageAnnotator->labelDetection($image);
$labels = $response->getLabelAnnotations();

$Retorno = '';
if ($labels) {
    foreach ($labels as $label) {
        if (empty($Retorno)){
            $Retorno .= $label->getDescription();
        } else {
            $Retorno .= ", ".$label->getDescription();
        }
    }
} else {
    $Retorno[] = 'No label found';
}
echo json_encode($Retorno);