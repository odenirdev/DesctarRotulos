<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Detectar Rótulos</title>
    <script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
    <style>
        html,
        body {
            height: 100%;
            background-color: #ffe083;
        }

        header {
            top: 0px;
            height: 10%;
        }

        footer {
            bottom: 0px;
            height: 5%;
        }

        section {
            display: flex;
            justify-content: center;
            background-color: white;
            height: 80%;
            margin: 0 10%;
            padding: 1%;
        }

        #imagem {
            background-color: red;
            width: 100%;
            height: 100%;
        }
    </style>

    <script>
        $(document).on('click', '#entrada', function() {
            $('#imagem').html('<img src=foto/foto.jpg>');

            $.ajax({
                url: 'model/geral.php',
                type: "GET",
                success: function(R) {
                    $('#rotulos').html(R);
                }
            });
        });
    </script>
</head>

<body>
    <header>
        <h1>Detectar Rótulos</h1>
    </header>
    <section>
        <div style="width: 40%; height: 80%;">
            <div id="imagem"></div>
            <input id="entrada" type="submit">
            <div id="rotulos"></div>
        </div>
    </section>
    <footer>
        <small>Copyright Odenir Gomes</small>
    </footer>
</body>

</html>